Zeko Lite WordPress Theme, Copyright 2017 Anariel Design
Zeko Lite is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

Zeko Lite WordPress Theme is derived from Underscores WordPress Theme, Copyright 2013 Automattic, Inc.
Underscores WordPress Theme is distributed under the terms of the GNU GPL

Zeko Lite WordPress Theme bundles the following third-party resources:

Genericons icon font, Copyright 2013 Automattic
Genericons are licensed under the terms of the GNU GPL, Version 2 (or later)
Source: http://www.genericons.com

Google Fonts
Open Sans	SIL Open Font License, 1.1
OpenSans-Light.ttf: Digitized data copyright 2010-2011, Google Corporation.
OpenSans-LightItalic.ttf: Digitized data copyright 2010-2011, Google Corporation.
OpenSans-Regular.ttf: Digitized data copyright 2010-2011, Google Corporation.
OpenSans-Italic.ttf: Digitized data copyright 2010-2011, Google Corporation.
OpenSans-SemiBold.ttf: Digitized data copyright 2011, Google Corporation.
OpenSans-SemiBoldItalic.ttf: Digitized data copyright 2010-2011, Google Corporation.
OpenSans-Bold.ttf: Digitized data copyright 2010-2011, Google Corporation.
OpenSans-BoldItalic.ttf: Digitized data copyright 2010-2011, Google Corporation.
OpenSans-ExtraBold.ttf: Digitized data copyright 2011, Google Corporation.
OpenSans-ExtraBoldItalic.ttf: Digitized data copyright 2010-2011, Google Corporation.
Oswald	SIL Open Font License, 1.1
Oswald-ExtraLight.ttf: Copyright 2016 The Oswald Project Authors (contact@sansoxygen.com)
Oswald-Light.ttf: Copyright 2016 The Oswald Project Authors (contact@sansoxygen.com)
Oswald-Regular.ttf: Copyright 2016 The Oswald Project Authors (contact@sansoxygen.com)
Oswald-Medium.ttf: Copyright 2016 The Oswald Project Authors (contact@sansoxygen.com)
Oswald-SemiBold.ttf: Copyright 2016 The Oswald Project Authors (contact@sansoxygen.com)
Oswald-Bold.ttf: Copyright 2016 The Oswald Project Authors (contact@sansoxygen.com)
Source: https://www.google.com/fonts




